// ── Version ──────────────────────────────────────────────────────────────────
const CURRENT_VERSION = '1.0';
const VERSION_CHECK_URL = 'https://myndguard.github.io/MyndGuard/version.json';

async function checkForUpdates() {
  try {
    const res  = await fetch(VERSION_CHECK_URL + '?t=' + Date.now());
    const data = await res.json();
    if (data.version && data.version !== CURRENT_VERSION) {
      const banner = document.getElementById('update-banner');
      if (banner) banner.style.display = 'block';
    }
  } catch(e) {}
}

checkForUpdates();

// MyndGuard Popup Logic

let currentTab = 'insights';

function switchTab(name) {
  currentTab = name;
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
  const tabEl = document.getElementById('tab-' + name);
  const panelEl = document.getElementById('panel-' + name);
  if (tabEl) tabEl.classList.add('active');
  if (panelEl) panelEl.classList.add('active');
}

// ─── On Load ─────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
  // Wire up tab buttons
  document.getElementById('tab-insights').addEventListener('click', () => switchTab('insights'));
  document.getElementById('tab-patterns').addEventListener('click', () => switchTab('patterns'));
  document.getElementById('tab-history').addEventListener('click', () => switchTab('history'));
  document.getElementById('tab-email').addEventListener('click', () => switchTab('email'));

  // Wire up action buttons
  document.getElementById('analyze-btn').addEventListener('click', runAnalysis);
  document.getElementById('add-guardian-email-btn').addEventListener('click', () => addEmail('guardian'));
  document.getElementById('save-email-btn').addEventListener('click', saveEmailSettings);
  document.getElementById('test-email-btn').addEventListener('click', sendTestEmail);

  // Allow pressing Enter in guardian email input
  document.getElementById('guardian-email-input').addEventListener('keydown', e => { if (e.key === 'Enter') addEmail('guardian'); });

  await loadSettings();
  await loadEmailSettings();
  await applyConfig();
  await autoDetectGoogleAccount(); // Auto-link signed-in Google account
  await loadLastAnalysis();
  await loadHistory();
});

async function loadSettings() {
  // Settings are loaded silently from encrypted config — nothing shown to user
}

// ─── Auto Google Account Detection ───────────────────────────────────────────
async function autoDetectGoogleAccount() {
  // First check if we already have it stored
  const stored = await storageGet(['googleEmail', 'googleName', 'googlePicture']);
  if (stored.googleEmail) {
    const alreadyAdded = registeredEmails.find(e => e.email === stored.googleEmail);
    if (!alreadyAdded) {
      registeredEmails.push({ email: stored.googleEmail, role: 'user', autoLinked: true });
      await storageSet({ emailList: registeredEmails });
    }
    showLinkedAccount(stored.googleEmail, stored.googleName || 'User', stored.googlePicture || '');
    renderEmailList();
    return;
  }

  // ── Method 1: chrome.identity.getProfileUserInfo (reads Chrome profile directly)
  try {
    const userInfo = await new Promise((resolve, reject) => {
      chrome.identity.getProfileUserInfo({ accountStatus: 'ANY' }, (info) => {
        if (chrome.runtime.lastError) reject(chrome.runtime.lastError);
        else resolve(info);
      });
    });

    if (userInfo && userInfo.email) {
      const email = userInfo.email;
      const name = email.split('@')[0]; // Use email prefix as name fallback
      await saveAndShowAccount(email, name, '');
      return;
    }
  } catch (e) {
    console.warn('[MyndGuard] getProfileUserInfo failed:', e.message);
  }

  // ── Method 2: OAuth token (interactive) as fallback
  try {
    const token = await getAuthToken(true);
    if (token) {
      const res = await fetch('https://www.googleapis.com/oauth2/v2/userinfo', {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        const profile = await res.json();
        if (profile.email) {
          await saveAndShowAccount(profile.email, profile.name || profile.email.split('@')[0], profile.picture || '');
          return;
        }
      }
    }
  } catch (e) {
    console.warn('[MyndGuard] OAuth fallback failed:', e.message);
  }

  // ── All methods failed — show manual input fallback
  showManualEmailFallback();
}

async function saveAndShowAccount(email, name, picture) {
  await storageSet({ googleEmail: email, googleName: name, googlePicture: picture });
  const alreadyAdded = registeredEmails.find(e => e.email === email);
  if (!alreadyAdded) {
    registeredEmails.push({ email, role: 'user', autoLinked: true });
    await storageSet({ emailList: registeredEmails });
  }
  renderEmailList();
  showLinkedAccount(email, name, picture);
}

function showManualEmailFallback() {
  // Show a simple manual input if auto-detect fails
  const badge = document.getElementById('google-account-badge');
  if (badge) {
    badge.style.display = 'flex';
    badge.style.flexDirection = 'column';
    badge.style.gap = '8px';
    badge.innerHTML = `
      <div style="font-size:12px;color:var(--muted)">⚠️ Could not auto-detect Google account. Enter your email manually:</div>
      <div style="display:flex;gap:8px">
        <input type="email" id="manual-user-email" placeholder="your@gmail.com"
          style="flex:1;padding:8px 10px;background:#22263a;border:1px solid rgba(255,255,255,0.1);border-radius:8px;color:var(--text);font-size:12px;outline:none" />
        <button id="manual-email-confirm-btn"
          style="padding:8px 12px;background:var(--accent);border:none;border-radius:8px;color:#0f1117;font-size:12px;font-weight:700;cursor:pointer">
          Link
        </button>
      </div>
    `;
    document.getElementById('manual-email-confirm-btn').addEventListener('click', async () => {
      const email = document.getElementById('manual-user-email').value.trim();
      if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        showStatus('email-status', '⚠️ Please enter a valid email.', 'error');
        return;
      }
      await saveAndShowAccount(email, email.split('@')[0], '');
      showStatus('email-status', '✅ Email linked!', 'success');
    });
  }
}

function getAuthToken(interactive) {
  return new Promise((resolve) => {
    chrome.identity.getAuthToken({ interactive }, (token) => {
      if (chrome.runtime.lastError || !token) resolve(null);
      else resolve(token);
    });
  });
}

function showLinkedAccount(email, name, picture) {
  const badge = document.getElementById('google-account-badge');
  if (!badge) return;
  document.getElementById('google-account-name').textContent = name;
  document.getElementById('google-account-email').textContent = email;
  // Replace icon with profile picture if available
  if (picture) {
    const iconEl = badge.querySelector('div[style*="font-size:20px"]');
    if (iconEl) iconEl.outerHTML = `<img src="${picture}" style="width:32px;height:32px;border-radius:50%;flex-shrink:0" />`;
  }
  badge.style.display = 'flex';
}

// ─── Silent Decryption (hardcoded secret — obfuscated) ───────────────────────
const _k = () => ['M','i','n','d','G','u','a','r','d','@','2','0','2','5','#','S','e','c','r','e','t','!','K','e','y','$','X','9','Z','q'].join('');

async function deriveKey(password, salt) {
  const enc = new TextEncoder();
  const keyMaterial = await crypto.subtle.importKey('raw', enc.encode(password), 'PBKDF2', false, ['deriveKey']);
  return crypto.subtle.deriveKey(
    { name: 'PBKDF2', salt, iterations: 100000, hash: 'SHA-256' },
    keyMaterial,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt', 'decrypt']
  );
}

async function decryptData(encryptedB64, password) {
  const combined = Uint8Array.from(atob(encryptedB64), c => c.charCodeAt(0));
  const salt = combined.slice(0, 16);
  const iv = combined.slice(16, 28);
  const data = combined.slice(28);
  const key = await deriveKey(password, salt);
  const decrypted = await crypto.subtle.decrypt({ name: 'AES-GCM', iv }, key, data);
  return new TextDecoder().decode(decrypted);
}

// ─── Auto-load from config.js (silent, no prompt) ────────────────────────────
async function applyConfig() {
  if (typeof MYNDGUARD_ENCRYPTED !== 'undefined' && MYNDGUARD_ENCRYPTED !== 'PASTE_ENCRYPTED_STRING_HERE') {
    try {
      const decrypted = await decryptData(MYNDGUARD_ENCRYPTED, _k());
      const c = JSON.parse(decrypted);
      await applyConfigValues(c);
    } catch {
      console.warn('[MyndGuard] Config decryption failed — check your config.js');
    }
    return;
  }
  // Handle plain config (legacy)
  if (typeof MYNDGUARD_CONFIG !== 'undefined' && MYNDGUARD_CONFIG !== null) {
    await applyConfigValues(MYNDGUARD_CONFIG);
  }
}

async function applyConfigValues(c) {
  // Only apply API keys — emails are always managed by the user in the app
  if (c.groqApiKey && !c.groqApiKey.includes('YOUR_')) {
    await storageSet({ apiKey: c.groqApiKey });
    const el = document.getElementById('api-key-input');
    if (el) el.value = c.groqApiKey;
  }
  if (c.emailjsServiceId && !c.emailjsServiceId.includes('YOUR_')) {
    await storageSet({
      emailjsServiceId: c.emailjsServiceId,
      emailjsTemplateId: c.emailjsTemplateId,
      emailjsPublicKey: c.emailjsPublicKey
    });
    const s = document.getElementById('emailjs-service-id');
    const t = document.getElementById('emailjs-template-id');
    const p = document.getElementById('emailjs-public-key');
    if (s) s.value = c.emailjsServiceId;
    if (t) t.value = c.emailjsTemplateId;
    if (p) p.value = c.emailjsPublicKey;
  }
  // Emails are NOT loaded from config — users manage them freely in the app
}

async function saveSettings() {
  // Settings are managed via encrypted config — nothing to save here
}

// ─── Analysis ────────────────────────────────────────────────────────────────
async function runAnalysis() {
  const { apiKey } = await storageGet(['apiKey']);
  if (!apiKey) {
    showStatus('insights-status', '⚠️ Configuration not loaded yet. Please wait or reload the extension.', 'error');
    return;
  }

  const btn = document.getElementById('analyze-btn');
  btn.disabled = true;
  btn.innerHTML = '<span class="spinner"></span>Analyzing...';
  
  document.getElementById('insights-empty').style.display = 'none';
  document.getElementById('insights-data').style.display = 'none';
  document.getElementById('insights-loading').style.display = 'block';
  showStatus('insights-status', '');

  try {
    const result = await sendMessage({ action: 'runAnalysis', apiKey });
    if (result.success) {
      renderAnalysis(result.result);
      await loadHistory();
      showStatus('insights-status', '✅ Analysis complete', 'success');
      // Send email reports silently
      sendReportEmails(result.result).catch(() => {});
    } else {
      throw new Error(result.error);
    }
  } catch (err) {
    document.getElementById('insights-loading').style.display = 'none';
    document.getElementById('insights-empty').style.display = 'block';
    showStatus('insights-status', '❌ ' + (err.message || 'Analysis failed'), 'error');
  } finally {
    btn.disabled = false;
    btn.innerHTML = '🔍 Analyze Now';
  }
}

async function loadLastAnalysis() {
  const data = await storageGet(['lastAnalysis']);
  if (data.lastAnalysis) {
    renderAnalysis(data.lastAnalysis);
  }
}

function renderAnalysis(result) {
  const { analysis, categorySummary, timePatterns, totalSites, timestamp, youtubeData } = result;

  document.getElementById('insights-loading').style.display = 'none';
  document.getElementById('insights-empty').style.display = 'none';
  document.getElementById('insights-data').style.display = 'block';

  // Score ring
  const score = Math.min(10, Math.max(1, analysis.mood_score || 5));
  const circumference = 188.4;
  const offset = circumference - (score / 10) * circumference;
  const circle = document.getElementById('score-circle');
  circle.style.strokeDashoffset = offset;

  const scoreColors = score >= 7 ? 'var(--green)' : score >= 4 ? 'var(--amber)' : 'var(--red)';
  circle.style.stroke = scoreColors;

  document.getElementById('score-number').textContent = score;
  document.getElementById('score-label').textContent = scoreLabel(score);
  document.getElementById('score-sublabel').textContent = `${totalSites} pages · ${youtubeData?.totalVideos || 0} videos`;
  document.getElementById('score-time').textContent = `Last updated: ${formatTime(timestamp)}`;

  // Summary
  document.getElementById('summary-text').textContent = analysis.summary || 'No summary available.';

  // YouTube insights card
  const existingYT = document.getElementById('youtube-insights-card');
  if (existingYT) existingYT.remove();
  if (analysis.youtube_insights && youtubeData?.totalVideos > 0) {
    const ytCard = document.createElement('div');
    ytCard.id = 'youtube-insights-card';
    ytCard.style.cssText = 'background:rgba(255,0,0,0.06);border:1px solid rgba(255,80,80,0.2);border-radius:12px;padding:14px;margin-bottom:14px;';
    ytCard.innerHTML = `
      <div style="font-size:11px;color:#f87171;font-weight:600;text-transform:uppercase;letter-spacing:1px;margin-bottom:6px">▶ YouTube Insights · ${youtubeData.totalVideos} videos</div>
      <div style="font-size:13px;color:var(--muted);line-height:1.6">${analysis.youtube_insights}</div>
      ${youtubeData.contentTypes ? `<div style="font-size:10px;color:var(--muted);margin-top:8px">${Object.entries(youtubeData.contentTypes).map(([k,v]) => `${k.replace(/_/g,' ')}: ${v}`).join(' · ')}</div>` : ''}
    `;
    document.getElementById('summary-text').after(ytCard);
  }

  // Highlights
  const highlights = analysis.positive_highlights || [];
  const hlSection = document.getElementById('highlights-section');
  if (highlights.length > 0) {
    hlSection.style.display = 'block';
    document.getElementById('highlights-list').innerHTML = highlights
      .map(h => `<span class="highlight-chip">${h}</span>`).join('');
  } else {
    hlSection.style.display = 'none';
  }

  // Recommendations
  const recos = analysis.recommendations || [];
  document.getElementById('reco-list').innerHTML = recos.length
    ? recos.map(r => `
      <div class="reco-item ${r.priority || 'low'}">
        <div class="reco-title">${r.title}</div>
        <div class="reco-detail">${r.detail}</div>
      </div>`).join('')
    : '<div class="reco-detail" style="color:var(--muted);padding:8px">No recommendations at this time.</div>';

  // Patterns tab
  const patterns = analysis.patterns || [];
  document.getElementById('patterns-empty').style.display = patterns.length ? 'none' : 'block';
  document.getElementById('patterns-data').style.display = patterns.length ? 'block' : 'none';

  document.getElementById('pattern-list').innerHTML = patterns
    .map(p => `
      <div class="pattern-item">
        <div class="pattern-dot ${p.type || 'neutral'}"></div>
        <div>
          <div class="pattern-name">${p.label}</div>
          <div class="pattern-desc">${p.description}</div>
        </div>
      </div>`).join('');

  // Category bars
  const cats = categorySummary?.categories || {};
  const maxCat = Math.max(...Object.values(cats), 1);
  const catNames = {
    news: '📰 News',
    social_media: '📱 Social',
    mental_health_search: '💭 Mental Health',
    shopping: '🛍 Shopping',
    entertainment: '🎬 Entertainment',
    work_technical: '💻 Work/Tech',
    search: '🔍 Search',
    health_info: '🏥 Health',
    finance: '💰 Finance',
    education: '📚 Education',
    general: '🌐 General'
  };
  const sortedCats = Object.entries(cats).sort(([,a],[,b]) => b-a).slice(0, 8);
  document.getElementById('category-bars').innerHTML = sortedCats.map(([k, v]) => `
    <div class="cat-row">
      <div class="cat-label">${catNames[k] || k}</div>
      <div class="cat-bar-bg">
        <div class="cat-bar-fill" style="width:${Math.round((v/maxCat)*100)}%"></div>
      </div>
      <div class="cat-count">${v}</div>
    </div>`).join('');

  // Watch areas
  const watches = analysis.watch_areas || [];
  document.getElementById('watch-areas').innerHTML = watches.length
    ? watches.map(w => `<div class="summary-card" style="margin-bottom:7px;font-size:12px">⚠️ ${w}</div>`).join('')
    : '<div style="color:var(--muted);font-size:12px;padding:8px">No watch areas identified.</div>';
}

// ─── History ─────────────────────────────────────────────────────────────────
async function loadHistory() {
  const { analysisLog = [] } = await storageGet(['analysisLog']);
  const el = document.getElementById('history-list');
  if (!analysisLog.length) {
    el.innerHTML = `<div class="empty-state"><div class="emoji">📋</div><strong>No history yet</strong>Past analyses will appear here.</div>`;
    return;
  }
  const recent = [...analysisLog].reverse().slice(0, 15);
  el.innerHTML = recent.map(entry => {
    const score = entry.analysis?.mood_score || 5;
    const color = score >= 7 ? 'var(--green)' : score >= 4 ? 'var(--amber)' : 'var(--red)';
    return `
      <div class="pattern-item" style="cursor:pointer;margin-bottom:8px" onclick='renderAnalysis(${JSON.stringify(entry).replace(/'/g, "&apos;")})'>
        <div class="pattern-dot" style="background:${color}"></div>
        <div>
          <div class="pattern-name">${formatTime(entry.timestamp)}</div>
          <div class="pattern-desc">Score: ${score}/10 · ${entry.totalSites || 0} pages</div>
        </div>
      </div>`;
  }).join('');
}

// ─── Helpers ──────────────────────────────────────────────────────────────────
function scoreLabel(s) {
  if (s >= 9) return '🌟 Excellent Wellness';
  if (s >= 7) return '😊 Good Wellness';
  if (s >= 5) return '😐 Moderate Wellness';
  if (s >= 3) return '😟 Some Concerns';
  return '⚠️ Needs Attention';
}

function formatTime(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
}

function showStatus(id, msg, type = '') {
  const el = document.getElementById(id);
  if (el) { el.textContent = msg; el.className = 'status-msg ' + type; }
}

function storageGet(keys) {
  return new Promise(r => chrome.storage.local.get(keys, r));
}

function storageSet(data) {
  return new Promise(r => chrome.storage.local.set(data, r));
}

function sendMessage(msg) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage(msg, response => {
      if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
      else resolve(response);
    });
  });
}

// ─── Email Functions ──────────────────────────────────────────────────────────
let registeredEmails = []; // { email, role }

async function loadEmailSettings() {
  const data = await storageGet(['emailList']);
  registeredEmails = data.emailList || [];
  renderEmailList();
}

async function saveEmailSettings() {
  await storageSet({ emailList: registeredEmails });
  showStatus('email-status', '✅ Emails saved!', 'success');
}

function addEmail(role) {
  const inputId = role === 'user' ? 'user-email-input' : 'guardian-email-input';
  const input = document.getElementById(inputId);
  const email = input.value.trim();
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    showStatus('email-status', '⚠️ Please enter a valid email address.', 'error');
    return;
  }
  if (registeredEmails.find(e => e.email === email)) {
    showStatus('email-status', '⚠️ This email is already registered.', 'error');
    return;
  }
  registeredEmails.push({ email, role });
  input.value = '';
  renderEmailList();
  storageSet({ emailList: registeredEmails });
  showStatus('email-status', `✅ ${role === 'guardian' ? 'Guardian' : 'User'} email added!`, 'success');
}

function removeEmail(email) {
  registeredEmails = registeredEmails.filter(e => e.email !== email);
  renderEmailList();
  storageSet({ emailList: registeredEmails });
}

function renderEmailList() {
  const el = document.getElementById('email-list');
  // Only show guardian emails in the list — user email is shown in the badge above
  const guardianEmails = registeredEmails.filter(e => e.role === 'guardian');
  if (!guardianEmails.length) {
    el.innerHTML = '<div style="color:var(--muted);font-size:12px;padding:8px 0">No guardian emails added yet.</div>';
    return;
  }
  el.innerHTML = guardianEmails.map(e => `
    <div class="email-tag">
      <div class="email-tag-info">
        <div class="email-tag-addr">${e.email}</div>
        <div class="email-tag-role">👨‍👩‍👧 Guardian</div>
      </div>
      <button class="email-tag-remove" data-email="${e.email}" title="Remove">✕</button>
    </div>`).join('');
  el.querySelectorAll('.email-tag-remove').forEach(btn => {
    btn.addEventListener('click', () => removeEmail(btn.dataset.email));
  });
}

async function sendTestEmail() {
  const data = await storageGet(['lastAnalysis']);
  if (!data.lastAnalysis) {
    showStatus('email-status', '⚠️ Run an analysis first, then send a test email.', 'error');
    return;
  }
  showStatus('email-status', '📤 Sending test email...', '');
  try {
    await sendReportEmails(data.lastAnalysis, true);
    showStatus('email-status', '✅ Test email sent successfully!', 'success');
  } catch (err) {
    showStatus('email-status', '❌ ' + err.message, 'error');
  }
}

async function sendReportEmails(result, isTest = false) {
  const data = await storageGet(['emailList', 'emailjsServiceId', 'emailjsTemplateId', 'emailjsPublicKey']);
  const emails = data.emailList || [];
  if (!emails.length) return;

  const serviceId = data.emailjsServiceId;
  const templateId = data.emailjsTemplateId;
  const publicKey = data.emailjsPublicKey;
  if (!serviceId || !templateId || !publicKey) throw new Error('EmailJS not configured. Please fill in all EmailJS fields.');

  const { analysis, totalSites, timestamp } = result;
  const youtubeData = result.youtubeData || {};
  const recoText = (analysis.recommendations || []).map(r => `• ${r.title}: ${r.detail}`).join('\n');
  const patternsText = (analysis.patterns || []).map(p => `• ${p.label} (${p.type}): ${p.description}`).join('\n');
  const youtubeText = youtubeData.totalVideos > 0
    ? `${youtubeData.totalVideos} videos watched\n${analysis.youtube_insights || ''}\nContent: ${Object.entries(youtubeData.contentTypes || {}).map(([k,v]) => `${k.replace(/_/g,' ')}: ${v}`).join(', ')}`
    : 'No YouTube activity';

  for (const entry of emails) {
    const res = await fetch('https://api.emailjs.com/api/v1.0/email/send', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        service_id: serviceId,
        template_id: templateId,
        user_id: publicKey,
        template_params: {
          to_email: entry.email,
          user_name: entry.role === 'guardian' ? 'Guardian' : 'User',
          subject: isTest ? '[TEST] MyndGuard Wellness Report' : `MyndGuard Wellness Report – ${formatTime(timestamp)}`,
          date: formatTime(timestamp),
          score: `${analysis.mood_score || '?'}/10 – ${scoreLabel(analysis.mood_score || 5)}`,
          summary: analysis.summary || 'No summary available.',
          recommendations: recoText || 'No recommendations.',
          patterns: patternsText || 'No patterns detected.',
          total_sites: totalSites || 0,
          highlights: (analysis.positive_highlights || []).join(', ') || 'None',
          watch_areas: (analysis.watch_areas || []).join(', ') || 'None',
          youtube_summary: youtubeText,
          website_url: 'https://myndguard.github.io/MyndGuard/',
          testimonials_url: 'https://myndguard.github.io/MyndGuard/#testimonials'
        }
      })
    });
    if (!res.ok) {
      const err = await res.text();
      throw new Error(`EmailJS error: ${err}`);
    }
  }
}
